<?php

return [
    'adminEmail' => 'admin@example.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Example.com mailer',
    'teletypeApiUrl' => 'https://api.teletype.app/public/api/v1/',
    'teletypeAccessToken' => 'hYIb3cuthxrSELrylOiLEC1LC5Gfxh_18RfxHcKzcWIFQ9kMg1IDb_sW6bfsv754',
    'teletypeEndpoints' => [
        'new message' => 'new-message',
        'success send' => 'success-send',
        'messages' => 'messages',
        'messageSend' => 'message/send'
    ]
];
